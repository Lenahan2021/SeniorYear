public class Entry {
    public String name;
    public String username;
    public String password;
    public String categoryType;

    public Entry(String name, String user, String pass, String cat) {
        this.name = name;
        this.username = user;
        this.password = pass;
        this.categoryType = cat;
    }
}
